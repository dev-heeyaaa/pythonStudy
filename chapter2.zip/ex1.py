from selenium import webdriver

driverPath = "C:/Users/ITPS/Desktop/driver/chromedriver.exe"

URL = "https://www.naver.com"

driver = webdriver.Chrome(executable_path=driverPath)
driver.get(url=URL)
