# 영화인 페이지에 들어가서 영화인 50위까지 긁어와라.
import requests
from bs4 import BeautifulSoup

url = 'https://movie.naver.com/movie/sdb/rank/rmovie.nhn?sel=cnt&date=20210401'
#param_dic = {}

#response = requests.get(url, param_dic)
response = requests.get(url)
# 여기까지 웹페이지 접근

try:
    html = response.text
    soup = BeautifulSoup(html, "html.parser")

    movie = []
    movieList = soup.find_all("td", class_="title")
    # 사람들이 전부 td 태그 안에 들어가있음


    for ranker in movieList:
        name = ranker.text
        movie.append(name.strip())
        # 영화 이름을 공백을 제거하면서 추가

    for i in range(0, len(movie)):
        print("{}위: {}".format(i+1, movie[i]))

except:
    print("데이터를 불러오지 못했습니다.")

