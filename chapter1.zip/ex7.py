# 영화 랭킹 변동폭
import requests
from bs4 import BeautifulSoup

url = 'https://movie.naver.com/movie/sdb/rank/rmovie.nhn?sel=cnt&date=20210401'
#param_dic = {}

#response = requests.get(url, param_dic)
response = requests.get(url)
# 여기까지 웹페이지 접근

html = response.text
soup = BeautifulSoup(html, "html.parser")

movie = []
movieList = soup.find_all("td", class_="title")
    # 사람들이 전부 td 태그 안에 들어가있음


for ranker in movieList:
    name = ranker.text
    movie.append(name.strip())
        # 영화 이름을 공백을 제거하면서 추가

# 변동폭 출력이 안 됨
rangeTagList = soup.find_all("td", class_="range")
rangeList = []
for rangeTag in rangeTagList:
    rangeList.append(rangeTag.text)

# 변동폭의 상승 하락 여부에 상관없이 순위의 변동이 생긴 앱 이름만 출력하세요

for i in range(0, len(movie)):
    if rangeList[i] != 0:
        print("{}위: {} / {}".format(i+1, movie[i], rangeList[i]))

