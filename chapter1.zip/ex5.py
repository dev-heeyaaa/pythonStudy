# 영화인 페이지에 들어가서 영화인 50위까지 긁어와라.
import requests
from bs4 import BeautifulSoup

url = 'https://movie.naver.com/movie/sdb/rank/rpeople.nhn'
param_dic = {}

response = requests.get(url, param_dic)

try:
    html = response.text
    soup = BeautifulSoup(html, "html.parser")
    movie_in = soup.find_all("td", class_="title")
    # 사람들이 전부 td 태그 안에 들어가있음

    for ranker in movie_in:
        iamRanker = ranker.text
        print(iamRanker)

except:
    print("데이터를 불러오지 못했습니다.")

